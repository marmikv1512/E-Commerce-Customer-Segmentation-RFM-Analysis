import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

np.random.seed(7)

SNAPSHOT_DATE = datetime(2024, 12, 31)
N_CUSTOMERS = 2000
N_TRANSACTIONS = 18000

SEGMENT_MAP = {
    (5, 5): 'Champions',
    (5, 4): 'Champions',
    (4, 5): 'Champions',
    (4, 4): 'Loyal Customers',
    (3, 5): 'Loyal Customers',
    (5, 3): 'Potential Loyalists',
    (4, 3): 'Potential Loyalists',
    (3, 4): 'Potential Loyalists',
    (5, 2): 'Recent Customers',
    (5, 1): 'Recent Customers',
    (4, 1): 'Promising',
    (4, 2): 'Promising',
    (3, 3): 'Need Attention',
    (3, 2): 'Need Attention',
    (3, 1): 'About to Sleep',
    (2, 3): 'At Risk',
    (2, 2): 'At Risk',
    (2, 1): 'At Risk',
    (1, 3): 'Cant Lose Them',
    (1, 2): 'Cant Lose Them',
    (1, 1): 'Lost',
    (2, 4): 'At Risk',
    (2, 5): 'Cant Lose Them',
    (1, 4): 'Cant Lose Them',
    (1, 5): 'Cant Lose Them',
}

SEGMENT_ACTIONS = {
    'Champions': {
        'channel': 'Email + WhatsApp',
        'message': 'Exclusive early access, loyalty rewards, brand ambassador program',
        'priority': 'P1',
        'goal': 'Retain & upsell',
        'color': '#3fb950'
    },
    'Loyal Customers': {
        'channel': 'Email',
        'message': 'Personalised recommendations, loyalty points, VIP offers',
        'priority': 'P1',
        'goal': 'Grow share of wallet',
        'color': '#58a6ff'
    },
    'Potential Loyalists': {
        'channel': 'Email + Retargeting',
        'message': 'Membership programme invite, product bundles, moderate discounts',
        'priority': 'P2',
        'goal': 'Convert to Loyal',
        'color': '#79c0ff'
    },
    'Recent Customers': {
        'channel': 'Email onboarding',
        'message': 'Welcome series, how-to guides, first repeat purchase incentive',
        'priority': 'P2',
        'goal': 'Drive 2nd purchase',
        'color': '#56d364'
    },
    'Promising': {
        'channel': 'Email + Push',
        'message': 'Best-sellers showcase, time-limited offer, social proof',
        'priority': 'P2',
        'goal': 'Increase frequency',
        'color': '#d2a679'
    },
    'Need Attention': {
        'channel': 'Email + SMS',
        'message': 'Re-engagement offer, "We miss you" campaign, curated picks',
        'priority': 'P2',
        'goal': 'Re-engage before churn',
        'color': '#d29922'
    },
    'About to Sleep': {
        'channel': 'Email + SMS',
        'message': 'Win-back discount, FOMO messaging, limited stock alerts',
        'priority': 'P3',
        'goal': 'Prevent churn',
        'color': '#e3b341'
    },
    'At Risk': {
        'channel': 'Email + Paid retargeting',
        'message': 'Strong win-back offer (15–20%), personalised outreach',
        'priority': 'P1',
        'goal': 'Recover revenue',
        'color': '#f85149'
    },
    'Cant Lose Them': {
        'channel': 'Direct outreach + Email',
        'message': 'High-value win-back, personal account manager, premium offer',
        'priority': 'P1',
        'goal': 'Prevent permanent loss',
        'color': '#ff7b72'
    },
    'Lost': {
        'channel': 'Email (low cost)',
        'message': 'Hail Mary discount, survey to understand churn reason',
        'priority': 'P3',
        'goal': 'Low-cost reactivation',
        'color': '#8b949e'
    },
}


def generate_transactions():
    customer_ids = [f"CUST-{str(i).zfill(5)}" for i in range(1, N_CUSTOMERS + 1)]

    customer_profiles = pd.DataFrame({
        'customer_id': customer_ids,
        'type': np.random.choice(
            ['champion', 'loyal', 'active', 'at_risk', 'churned'],
            size=N_CUSTOMERS,
            p=[0.08, 0.15, 0.35, 0.25, 0.17]
        )
    })

    recency_map = {
        'champion': (1, 30), 'loyal': (10, 60), 'active': (30, 120),
        'at_risk': (90, 270), 'churned': (200, 365)
    }
    freq_map = {
        'champion': (15, 50), 'loyal': (8, 20), 'active': (3, 10),
        'at_risk': (2, 6), 'churned': (1, 3)
    }
    monetary_map = {
        'champion': (500, 3000), 'loyal': (200, 900), 'active': (80, 350),
        'at_risk': (50, 200), 'churned': (20, 100)
    }

    records = []
    for _, row in customer_profiles.iterrows():
        ctype = row['type']
        n_orders = np.random.randint(*freq_map[ctype])
        last_purchase_days_ago = np.random.randint(*recency_map[ctype])
        last_purchase = SNAPSHOT_DATE - timedelta(days=last_purchase_days_ago)
        order_dates = sorted([
            last_purchase - timedelta(days=np.random.randint(0, 365))
            for _ in range(n_orders - 1)
        ] + [last_purchase])
        for d in order_dates:
            qty = np.random.randint(1, 5)
            price = round(np.random.uniform(*monetary_map[ctype]) / qty, 2)
            records.append({
                'customer_id': row['customer_id'],
                'order_date': d,
                'order_value_gbp': round(qty * price, 2)
            })

    df = pd.DataFrame(records)
    df['order_date'] = pd.to_datetime(df['order_date'])
    return df


def compute_rfm(df):
    rfm = df.groupby('customer_id').agg(
        last_order=('order_date', 'max'),
        frequency=('order_date', 'count'),
        monetary=('order_value_gbp', 'sum')
    ).reset_index()

    rfm['recency_days'] = (SNAPSHOT_DATE - rfm['last_order']).dt.days
    rfm['monetary'] = rfm['monetary'].round(2)

    rfm['R'] = pd.qcut(rfm['recency_days'], q=5, labels=[5, 4, 3, 2, 1]).astype(int)
    rfm['F'] = pd.qcut(rfm['frequency'].rank(method='first'), q=5, labels=[1, 2, 3, 4, 5]).astype(int)
    rfm['M'] = pd.qcut(rfm['monetary'], q=5, labels=[1, 2, 3, 4, 5]).astype(int)

    rfm['rfm_score'] = rfm['R'].astype(str) + rfm['F'].astype(str) + rfm['M'].astype(str)
    rfm['segment'] = rfm.apply(
        lambda x: SEGMENT_MAP.get((x['R'], x['F']), 'Need Attention'), axis=1
    )
    return rfm


def build_segment_summary(rfm):
    summary = rfm.groupby('segment').agg(
        customer_count=('customer_id', 'count'),
        avg_recency=('recency_days', 'mean'),
        avg_frequency=('frequency', 'mean'),
        avg_monetary=('monetary', 'mean'),
        total_revenue=('monetary', 'sum')
    ).reset_index()

    total_rev = summary['total_revenue'].sum()
    summary['revenue_share_pct'] = (summary['total_revenue'] / total_rev * 100).round(2)
    summary['avg_recency'] = summary['avg_recency'].round(1)
    summary['avg_frequency'] = summary['avg_frequency'].round(1)
    summary['avg_monetary'] = summary['avg_monetary'].round(2)
    summary['total_revenue'] = summary['total_revenue'].round(2)

    for col in ['channel', 'message', 'priority', 'goal', 'color']:
        summary[col] = summary['segment'].map(lambda s: SEGMENT_ACTIONS.get(s, {}).get(col, ''))

    return summary.sort_values('total_revenue', ascending=False)


def plot_dashboard(rfm, summary):
    fig = plt.figure(figsize=(22, 16), facecolor='#0d1117')
    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.48, wspace=0.38)

    C_BG = '#0d1117'
    C_PANEL = '#161b22'
    C_ACCENT = '#58a6ff'
    C_GREEN = '#3fb950'
    C_YELLOW = '#d29922'
    C_RED = '#f85149'
    C_TEXT = '#e6edf3'
    C_SUB = '#8b949e'
    C_BORDER = '#30363d'

    def styled_ax(ax):
        ax.set_facecolor(C_PANEL)
        ax.tick_params(colors=C_SUB, labelsize=8)
        for sp in ax.spines.values():
            sp.set_edgecolor(C_BORDER)
        return ax

    # KPI row
    ax_kpi = fig.add_subplot(gs[0, :])
    ax_kpi.set_facecolor(C_BG)
    ax_kpi.axis('off')

    total_rev = rfm['monetary'].sum()
    champions = summary[summary['segment'] == 'Champions']
    champ_rev_share = champions['revenue_share_pct'].values[0] if len(champions) else 0
    at_risk = summary[summary['segment'] == 'At Risk']
    at_risk_rev = at_risk['total_revenue'].values[0] if len(at_risk) else 0
    n_segments = rfm['segment'].nunique()

    kpis = [
        ("Total Customers", f"{len(rfm):,}", C_ACCENT, "Analysed in RFM model"),
        ("Total Revenue", f"£{total_rev/1e6:.2f}M", C_GREEN, "FY2024 cohort"),
        ("Champions Revenue Share", f"{champ_rev_share:.1f}%", C_YELLOW, "Top segment by value"),
        ("At-Risk Recoverable", f"£{at_risk_rev:,.0f}", C_RED, "Win-back opportunity"),
        ("Segments Identified", f"{n_segments}", C_ACCENT, "Behavioural clusters"),
    ]

    for i, (label, value, color, sub) in enumerate(kpis):
        x = 0.02 + i * 0.193
        rect = FancyBboxPatch((x, 0.08), 0.172, 0.82,
                              boxstyle="round,pad=0.02",
                              facecolor=C_PANEL, edgecolor=color,
                              linewidth=1.5, transform=ax_kpi.transAxes)
        ax_kpi.add_patch(rect)
        ax_kpi.text(x + 0.086, 0.67, value, transform=ax_kpi.transAxes,
                    color=color, fontsize=20, fontweight='bold', ha='center', va='center',
                    fontfamily='monospace')
        ax_kpi.text(x + 0.086, 0.40, label, transform=ax_kpi.transAxes,
                    color=C_TEXT, fontsize=9, fontweight='bold', ha='center', va='center')
        ax_kpi.text(x + 0.086, 0.20, sub, transform=ax_kpi.transAxes,
                    color=C_SUB, fontsize=7.5, ha='center', va='center')

    ax_kpi.set_title('E-Commerce Customer Segmentation  |  RFM Analysis  |  2,000 Customers  |  £6M+ Revenue',
                     color=C_TEXT, fontsize=13, fontweight='bold', pad=10, loc='left')

    # Revenue share by segment (horizontal bar)
    ax1 = styled_ax(fig.add_subplot(gs[1, :2]))
    seg_rev = summary.sort_values('revenue_share_pct', ascending=True)
    colors_bar = [SEGMENT_ACTIONS.get(s, {}).get('color', C_ACCENT) for s in seg_rev['segment']]
    bars = ax1.barh(seg_rev['segment'], seg_rev['revenue_share_pct'],
                    color=colors_bar, height=0.6, edgecolor='none', alpha=0.88)
    for bar, val in zip(bars, seg_rev['revenue_share_pct']):
        ax1.text(bar.get_width() + 0.3, bar.get_y() + bar.get_height()/2,
                 f'{val:.1f}%', color=C_TEXT, va='center', fontsize=8)
    ax1.set_title('Revenue Share by Segment (%)', color=C_TEXT, fontsize=10, pad=8)
    ax1.set_xlabel('Revenue Share (%)', color=C_SUB, fontsize=8)
    ax1.set_xlim(0, seg_rev['revenue_share_pct'].max() * 1.18)

    # Customer count donut
    ax2 = styled_ax(fig.add_subplot(gs[1, 2]))
    top_segs = summary.nlargest(6, 'customer_count')
    other_count = summary['customer_count'].sum() - top_segs['customer_count'].sum()
    labels = list(top_segs['segment']) + (['Other'] if other_count > 0 else [])
    sizes = list(top_segs['customer_count']) + ([other_count] if other_count > 0 else [])
    seg_colors = [SEGMENT_ACTIONS.get(s, {}).get('color', C_SUB) for s in top_segs['segment']] + ([C_SUB] if other_count > 0 else [])
    wedges, _, autotexts = ax2.pie(
        sizes, labels=None, autopct='%1.0f%%',
        colors=seg_colors, pctdistance=0.75,
        wedgeprops={'edgecolor': C_BG, 'linewidth': 2},
        startangle=140
    )
    for at in autotexts:
        at.set_color(C_BG); at.set_fontsize(7); at.set_fontweight('bold')
    ax2.legend(labels, loc='lower center', bbox_to_anchor=(0.5, -0.22),
               ncol=2, fontsize=7, labelcolor=C_TEXT, facecolor=C_PANEL, edgecolor=C_BORDER)
    ax2.set_title('Customer Distribution', color=C_TEXT, fontsize=10, pad=8)

    # RFM scatter: Recency vs Monetary
    ax3 = styled_ax(fig.add_subplot(gs[2, :2]))
    sample = rfm.sample(min(800, len(rfm)), random_state=1)
    seg_color_map = {s: SEGMENT_ACTIONS.get(s, {}).get('color', C_ACCENT) for s in rfm['segment'].unique()}
    for seg, grp in sample.groupby('segment'):
        ax3.scatter(grp['recency_days'], grp['monetary'],
                    c=seg_color_map.get(seg, C_ACCENT), alpha=0.55, s=18,
                    label=seg, edgecolors='none')
    ax3.set_title('RFM Scatter — Recency vs Monetary Value', color=C_TEXT, fontsize=10, pad=8)
    ax3.set_xlabel('Recency (Days Since Last Purchase)', color=C_SUB, fontsize=8)
    ax3.set_ylabel('Customer Lifetime Value (£)', color=C_SUB, fontsize=8)
    ax3.legend(loc='upper right', fontsize=6.5, labelcolor=C_TEXT,
               facecolor=C_PANEL, edgecolor=C_BORDER, markerscale=1.5, ncol=2)

    # Avg Monetary by Segment
    ax4 = styled_ax(fig.add_subplot(gs[2, 2]))
    seg_mon = summary.sort_values('avg_monetary', ascending=True)
    colors_mon = [SEGMENT_ACTIONS.get(s, {}).get('color', C_ACCENT) for s in seg_mon['segment']]
    ax4.barh(seg_mon['segment'], seg_mon['avg_monetary'],
             color=colors_mon, height=0.6, edgecolor='none', alpha=0.88)
    ax4.set_title('Avg Customer Value by Segment (£)', color=C_TEXT, fontsize=10, pad=8)
    ax4.set_xlabel('Avg Monetary Value (£)', color=C_SUB, fontsize=8)

    fig.text(0.5, 0.01,
             'RFM Model  |  2,000 customers  |  £6M+ revenue  |  7 behavioural segments  |  Segment-to-Action mapping exported',
             ha='center', color=C_SUB, fontsize=8)

    plt.savefig('outputs/rfm_dashboard.png', dpi=150, bbox_inches='tight',
                facecolor=C_BG, edgecolor='none')
    plt.close()
    print("[✓] Dashboard saved → outputs/rfm_dashboard.png")


def export_outputs(rfm, summary):
    rfm.to_csv('outputs/rfm_scored_customers.csv', index=False)
    summary.to_csv('outputs/segment_action_mapping.csv', index=False)

    at_risk_df = rfm[rfm['segment'].isin(['At Risk', 'Cant Lose Them'])]\
        .sort_values('monetary', ascending=False)
    at_risk_df.to_csv('outputs/at_risk_customers.csv', index=False)
    print("[✓] CSVs exported → outputs/")


def print_summary(rfm, summary):
    total_rev = rfm['monetary'].sum()
    print("\n" + "="*65)
    print("RFM CUSTOMER SEGMENTATION — ANALYSIS SUMMARY")
    print("="*65)
    print(f"\nTotal Customers     : {len(rfm):,}")
    print(f"Total Revenue       : £{total_rev:,.0f}")
    print(f"Segments Identified : {rfm['segment'].nunique()}")
    print(f"\nSegment Breakdown:")
    cols = ['segment', 'customer_count', 'revenue_share_pct', 'avg_monetary', 'priority']
    print(summary[cols].to_string(index=False))

    champs = summary[summary['segment'] == 'Champions']
    if len(champs):
        print(f"\n★ Champions  : {champs['customer_count'].values[0]} customers"
              f" | {champs['revenue_share_pct'].values[0]:.1f}% of revenue")

    at_risk = rfm[rfm['segment'].isin(['At Risk', 'Cant Lose Them'])]
    print(f"⚠ At-Risk    : {len(at_risk)} customers | £{at_risk['monetary'].sum():,.0f} recoverable")
    print("="*65)


if __name__ == '__main__':
    import os
    os.makedirs('outputs', exist_ok=True)

    print("Generating transaction data (2,000 customers)...")
    df = generate_transactions()
    print(f"[✓] {len(df):,} transactions generated")

    print("Computing RFM scores...")
    rfm = compute_rfm(df)
    summary = build_segment_summary(rfm)

    print_summary(rfm, summary)
    print("\nRendering dashboard...")
    plot_dashboard(rfm, summary)
    export_outputs(rfm, summary)
    print("\nDone.")
